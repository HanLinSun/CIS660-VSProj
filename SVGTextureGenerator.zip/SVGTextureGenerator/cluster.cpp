#include "cluster.h"

cluster::cluster()
{
}

void cluster::sample_cluster()
{
	
}

void cluster::set_id(int input)
{
	this->id = input;
}

int cluster::get_id()
{
	return this->id;
}
